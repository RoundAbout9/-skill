"""Inspect retained DOCX templates and patch only explicitly mapped text nodes."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from zipfile import ZipFile

from lxml import etree

ROOT = Path(__file__).resolve().parents[1]
NS = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def source_for(template):
    manifest = json.loads((ROOT / "references/templates.json").read_text(encoding="utf-8"))
    items = [x for x in manifest["templates"] if x["id"] == template]
    if len(items) != 1:
        raise ValueError("Unknown or duplicate template identifier")
    item = items[0]
    path = (ROOT / item["asset"]).resolve()
    if not path.is_relative_to((ROOT / "assets/templates").resolve()):
        raise ValueError("Template must be a retained asset")
    if digest(path.read_bytes()) != item["sha256"]:
        raise ValueError("Retained template hash mismatch; inspect the changed reference first")
    return path, item


def text_nodes(paragraph):
    return paragraph.findall(".//w:t", NS)


def paragraph_text(paragraph):
    return "".join(n.text or "" for n in text_nodes(paragraph))


def masked_xml(data):
    root = etree.fromstring(data)
    for node in root.findall(".//w:t", NS):
        node.text = "TEXT"
    return etree.tostring(root, method="c14n")


def inspect(template):
    path, item = source_for(template)
    if path.suffix.lower() != ".docx":
        return {
            "template": item,
            "notice": "Legacy Word DOC: edit through a compatible word processor or verified conversion. No binary text patch is supported.",
        }
    parts = []
    with ZipFile(path) as z:
        for name in z.namelist():
            if not name.startswith("word/") or not name.endswith(".xml"):
                continue
            root = etree.fromstring(z.read(name))
            paragraphs = []
            for i, p in enumerate(root.findall(".//w:p", NS)):
                runs = []
                for n in text_nodes(p):
                    run = n.getparent()
                    rpr = run.find("w:rPr", NS)
                    runs.append({
                        "text": n.text or "",
                        "run_properties_xml": etree.tostring(rpr, encoding="unicode") if rpr is not None else None,
                    })
                paragraphs.append({
                    "index": i,
                    "text": paragraph_text(p),
                    "runs": runs,
                    "contains_nested_paragraphs": bool(p.findall(".//w:p", NS)),
                    "contains_fields": bool(p.findall(".//w:fldChar", NS) or p.findall(".//w:fldSimple", NS)),
                })
            if paragraphs:
                parts.append({"part": name, "paragraphs": paragraphs})
    return {"template": item, "parts": parts}


def patch(template, changes_path, output):
    source, item = source_for(template)
    if source.suffix.lower() != ".docx":
        raise ValueError("Legacy DOC cannot be patched as DOCX; use a compatible document tool")
    destination = Path(output).resolve()
    if destination.suffix.lower() != ".docx":
        raise ValueError("DOCX output must have a .docx extension")
    if destination.is_relative_to(ROOT):
        raise ValueError("Write generated documents outside the skill package")
    if destination.exists():
        raise ValueError("Output exists; choose a new deliverable path")
    payload = json.loads(Path(changes_path).read_text(encoding="utf-8-sig"))
    changes = payload.get("changes")
    if not isinstance(changes, list) or not changes:
        raise ValueError("A nonempty changes array is required")
    original_hash = digest(source.read_bytes())
    trees, seen = {}, set()
    with ZipFile(source) as z:
        for change in changes:
            part = change.get("part", "word/document.xml")
            index = change.get("paragraph")
            if not isinstance(part, str) or not part.startswith("word/") or not part.endswith(".xml"):
                raise ValueError("Only explicit Word XML text parts may be patched")
            if type(index) is not int or index < 0:
                raise ValueError("Paragraph index must be a nonnegative integer")
            key = (part, index)
            if key in seen:
                raise ValueError("Duplicate paragraph target")
            seen.add(key)
            if part not in trees:
                trees[part] = etree.fromstring(z.read(part))
            paragraphs = trees[part].findall(".//w:p", NS)
            if index >= len(paragraphs):
                raise ValueError("Paragraph index out of range")
            paragraph = paragraphs[index]
            if paragraph.findall(".//w:p", NS):
                raise ValueError("Select the leaf text-box paragraph instead of its enclosing paragraph")
            if paragraph.findall(".//w:fldChar", NS) or paragraph.findall(".//w:fldSimple", NS):
                raise ValueError("Field editing requires a document-aware tool and field refresh")
            if paragraph_text(paragraph) != change.get("expect"):
                raise ValueError(f"Expected original text does not match: {part} paragraph {index}")
            nodes = text_nodes(paragraph)
            values = change.get("runs")
            if not isinstance(values, list) or len(values) != len(nodes) or not all(isinstance(x, str) for x in values):
                raise ValueError("runs must contain exactly one string for every existing w:t node")
            if any(any(ord(c) < 32 for c in value) for value in values):
                raise ValueError("Do not insert control characters or new paragraphs as text")
            for n, value in zip(nodes, values):
                n.text = value
        modified = {
            name: etree.tostring(tree, xml_declaration=True, encoding="UTF-8", standalone=True)
            for name, tree in trees.items()
        }
        for name, data in modified.items():
            if masked_xml(data) != masked_xml(z.read(name)):
                raise ValueError("A non-text XML structure changed")
        destination.parent.mkdir(parents=True, exist_ok=True)
        with ZipFile(destination, "w") as out:
            for info in z.infolist():
                out.writestr(info, modified.get(info.filename, z.read(info.filename)))
    with ZipFile(source) as a, ZipFile(destination) as b:
        if a.namelist() != b.namelist():
            raise ValueError("Package members changed")
        changed = [n for n in a.namelist() if a.read(n) != b.read(n)]
        if any(n not in modified for n in changed):
            raise ValueError("An unapproved package part changed")
        for name in changed:
            if masked_xml(a.read(name)) != masked_xml(b.read(name)):
                raise ValueError("Output non-text XML failed fidelity verification")
    if digest(source.read_bytes()) != original_hash:
        raise ValueError("Original template changed")
    return {
        "template_id": item["id"], "template_sha256": original_hash,
        "output": str(destination), "changed_parts": changed,
        "source_unchanged": True, "only_text_values_changed": True,
        "visual_pagination_verified": False,
    }


def main():
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest="command", required=True)
    a = sub.add_parser("inspect")
    a.add_argument("--template", required=True)
    a.add_argument("--output")
    b = sub.add_parser("patch")
    b.add_argument("--template", required=True)
    b.add_argument("--changes", required=True)
    b.add_argument("--output", required=True)
    b.add_argument("--report")
    args = p.parse_args()
    result_path = args.output if args.command == "inspect" else args.report
    if result_path:
        report = Path(result_path).resolve()
        if report.suffix.lower() != ".json":
            raise ValueError("Inspection and report outputs must be JSON files")
        if report.is_relative_to(ROOT):
            raise ValueError("Write inspection and report files outside the installed skill")
        if args.command == "patch" and report == Path(args.output).resolve():
            raise ValueError("Report path cannot overwrite the Word document")
    if args.command == "inspect":
        result = inspect(args.template)
    else:
        result = patch(args.template, args.changes, args.output)
    serialized = json.dumps(result, ensure_ascii=False, indent=2)
    if result_path:
        report.parent.mkdir(parents=True, exist_ok=True)
        report.write_text(serialized + "\n", encoding="utf-8")
    else:
        print(serialized)


if __name__ == "__main__":
    main()
