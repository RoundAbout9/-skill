"""Decimal-only arithmetic for legally reviewed interest periods; no legal inference."""
from __future__ import annotations

import argparse
from datetime import date, timedelta
from decimal import Decimal, ROUND_HALF_UP, localcontext
import json
from pathlib import Path


def amount(value, field):
    if isinstance(value, bool) or not isinstance(value, (str, int)):
        raise ValueError(f"{field} must be a decimal string or integer")
    result = Decimal(str(value))
    if not result.is_finite() or result < 0:
        raise ValueError(f"{field} must be finite and nonnegative")
    return result


def calculate(payload):
    principal = amount(payload["principal_balance"], "principal_balance")
    fee = amount(payload["fee_payable_to_applicant"], "fee_payable_to_applicant")
    totals = {"ordinary": Decimal(0), "late_additional": Decimal(0)}
    covered = {key: [] for key in totals}
    rows = []
    periods = payload.get("periods")
    if not isinstance(periods, list):
        raise ValueError("periods must be an array")
    with localcontext() as ctx:
        ctx.prec = 40
        for i, period in enumerate(periods):
            kind = period["kind"]
            if kind not in totals:
                raise ValueError("kind must be ordinary or late_additional")
            start, end = date.fromisoformat(period["start"]), date.fromisoformat(period["end"])
            if end < start:
                raise ValueError("Period ends before it starts")
            include_start, include_end = period["include_start"], period["include_end"]
            if type(include_start) is not bool or type(include_end) is not bool:
                raise ValueError("Both endpoint flags must be explicit booleans")
            first = start if include_start else start + timedelta(days=1)
            last = end if include_end else end - timedelta(days=1)
            days = max(0, (last - first).days + 1)
            # Adjacent segments for the same interest kind may share a boundary date,
            # but may not both charge that date.
            if days:
                for previous_first, previous_last in covered[kind]:
                    if first <= previous_last and previous_first <= last:
                        raise ValueError("Overlapping charged days within the same interest kind")
                covered[kind].append((first, last))
            base = amount(period["principal"], "period principal")
            has_annual, has_daily = "annual_rate" in period, "daily_rate" in period
            if has_annual == has_daily:
                raise ValueError("Provide exactly one of annual_rate and daily_rate")
            if has_annual:
                basis = period["year_basis"]
                if type(basis) is not int or basis not in (360, 365, 366):
                    raise ValueError("year_basis must explicitly be 360, 365 or 366")
                rate = amount(period["annual_rate"], "annual_rate")
                unrounded = base * rate * days / basis
                formula = f"{base} × {rate} × {days} ÷ {basis}"
            else:
                rate = amount(period["daily_rate"], "daily_rate")
                unrounded = base * rate * days
                formula = f"{base} × {rate} × {days}"
            totals[kind] += unrounded
            rows.append({
                "index": i, "kind": kind, "start": str(start), "end": str(end),
                "include_start": include_start, "include_end": include_end,
                "charged_first_day": str(first) if days else None,
                "charged_last_day": str(last) if days else None,
                "days": days, "formula": formula, "unrounded_interest": str(unrounded),
            })
        money = lambda value: value.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
        ordinary, late = money(totals["ordinary"]), money(totals["late_additional"])
        combined = money(principal + fee + ordinary + late)
    return {
        "principal_balance": str(money(principal)),
        "ordinary_interest": str(ordinary),
        "late_additional_interest": str(late),
        "fee_payable_to_applicant": str(money(fee)),
        "provisional_total": str(combined),
        "periods": rows,
        "warning": "Arithmetic only. Effective date, deadline/holiday adjustment, rates, bases, fee eligibility and payment allocation must already have been verified.",
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", required=True)
    parser.add_argument("--output")
    args = parser.parse_args()
    input_path = Path(args.input).resolve()
    result = calculate(json.loads(input_path.read_text(encoding="utf-8-sig")))
    serialized = json.dumps(result, ensure_ascii=False, indent=2) + "\n"
    if args.output:
        output_path = Path(args.output).resolve()
        if output_path == input_path:
            raise ValueError("Output cannot overwrite calculation input")
        if output_path.is_relative_to(Path(__file__).resolve().parents[1]):
            raise ValueError("Write calculation results outside the skill package")
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(serialized, encoding="utf-8")
    else:
        print(serialized, end="")


if __name__ == "__main__":
    main()
