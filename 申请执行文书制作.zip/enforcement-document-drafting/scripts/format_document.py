"""Clean generated DOCX whitespace and keep closing/signature lines with prior body text."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import re
from zipfile import ZipFile

from lxml import etree

ROOT = Path(__file__).resolve().parents[1]
NS = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}
W = "{" + NS["w"] + "}"
PROTECTED = {
    "sectPr", "drawing", "pict", "object", "fldChar", "instrText", "fldSimple",
    "bookmarkStart", "bookmarkEnd", "commentRangeStart", "commentRangeEnd", "commentReference",
    "footnoteReference", "endnoteReference", "sdt", "ins", "del", "moveFrom", "moveTo", "tab",
}


def text(paragraph):
    return "".join(paragraph.xpath(".//w:t/text()", namespaces=NS))


def compact(value):
    return re.sub(r"\s+", "", value)


def ordinary_blank(paragraph):
    if paragraph.tag != W + "p" or text(paragraph).strip():
        return False
    break_before = paragraph.find("w:pPr/w:pageBreakBefore", NS)
    if break_before is not None and break_before.get(W + "val", "1") not in ("0", "false", "off"):
        return False
    for n in paragraph.iter():
        local = etree.QName(n).localname
        if local in PROTECTED:
            return False
        if local == "br" and n.get(W + "type", "textWrapping") in ("page", "column"):
            return False
    return True


def signature(paragraph):
    value = compact(text(paragraph))
    return bool(re.match(r"^(申请执行人|申请人|法定代表人|委托代理人|委托诉讼代理人)(?:[（(][^）)]*[）)])?[:：]", value)) and not any(
        word in value for word in ("住所", "地址", "身份证", "信用代码")
    ) and len(value) <= 60


def date_line(paragraph):
    value = compact(text(paragraph))
    return bool(re.fullmatch(r"[0-9０-９〇○零一二三四五六七八九十年月日—_./\-]+", value)) and "年" in value and "日" in value


def find_closing(paragraphs):
    # All four retained forms contain 此致. Restrict fallback signature detection
    # to the tail so a first-page party identity is never treated as a closing.
    courteous = [i for i, p in enumerate(paragraphs) if compact(text(p)) in ("此致", "谨呈")]
    if courteous:
        return courteous[-1]
    start = max(0, len(paragraphs) - 10, len(paragraphs) // 2)
    candidates = [i for i in range(start, len(paragraphs)) if signature(paragraphs[i])]
    return candidates[0] if candidates else None


def ppr(paragraph):
    node = paragraph.find("w:pPr", NS)
    if node is None:
        node = etree.Element(W + "pPr")
        paragraph.insert(0, node)
    return node


PPR_ORDER = [
    "pStyle", "keepNext", "keepLines", "pageBreakBefore", "framePr", "widowControl",
    "numPr", "suppressLineNumbers", "pBdr", "shd", "tabs", "suppressAutoHyphens",
    "kinsoku", "wordWrap", "overflowPunct", "topLinePunct", "autoSpaceDE", "autoSpaceDN",
    "bidi", "adjustRightInd", "snapToGrid", "spacing", "ind", "contextualSpacing",
    "mirrorIndents", "suppressOverlap", "jc", "textDirection", "textAlignment",
    "textboxTightWrap", "outlineLvl", "divId", "cnfStyle", "rPr", "sectPr", "pPrChange",
]


def set_toggle(paragraph, name, value):
    properties = ppr(paragraph)
    old = properties.findall("w:" + name, NS)
    for node in old:
        properties.remove(node)
    node = etree.Element(W + name)
    node.set(W + "val", "1" if value else "0")
    rank = PPR_ORDER.index(name)
    for i, existing in enumerate(properties):
        local = etree.QName(existing).localname
        if local in PPR_ORDER and PPR_ORDER.index(local) > rank:
            properties.insert(i, node)
            return
    properties.append(node)


def significant_text(root):
    return [n.text for n in root.findall(".//w:t", NS) if n.text and n.text.strip()]


def collapse_soft_breaks(paragraph):
    if any(etree.QName(n).localname in PROTECTED for n in paragraph.iter()):
        return 0
    pending = False
    removed = 0
    for node in list(paragraph.iter()):
        local = etree.QName(node).localname
        if node.tag == W + "t" and (node.text or "").strip():
            pending = False
        elif node.tag in (W + "br", W + "cr"):
            if node.get(W + "type", "textWrapping") in ("page", "column"):
                pending = False
            elif pending:
                node.getparent().remove(node)
                removed += 1
            else:
                pending = True
    return removed


def format_document(input_path, output_path, keep_signature_blank=1):
    source, output = Path(input_path).resolve(), Path(output_path).resolve()
    if source.suffix.lower() != ".docx" or output.suffix.lower() != ".docx":
        raise ValueError("Use a compatible Word tool for .doc; this helper accepts DOCX only")
    if source.is_relative_to(ROOT) or output.is_relative_to(ROOT):
        raise ValueError("Format generated documents outside the skill; never alter template assets")
    if source == output or output.exists():
        raise ValueError("Choose a new output path; keep the filled source as an intermediate")
    if keep_signature_blank not in (0, 1):
        raise ValueError("keep_signature_blank must be 0 or 1")
    before_hash = hashlib.sha256(source.read_bytes()).hexdigest()
    with ZipFile(source) as z:
        before_xml = z.read("word/document.xml")
        root = etree.fromstring(before_xml)
        before_text = significant_text(root)
        body = root.find("w:body", NS)
        if body is None:
            raise ValueError("Missing Word body")
        original_paragraphs = list(body.findall("w:p", NS))
        start = find_closing(original_paragraphs)
        closing_original = original_paragraphs[start:] if start is not None else []
        preserve_signature_blanks = set()
        if keep_signature_blank and closing_original:
            for i, p in enumerate(closing_original):
                if not signature(p):
                    continue
                blank_group = []
                for candidate in closing_original[i + 1:]:
                    if ordinary_blank(candidate):
                        blank_group.append(candidate)
                    else:
                        if blank_group and (date_line(candidate) or signature(candidate)):
                            preserve_signature_blanks.add(blank_group[0])
                        break
        removed_blanks = 0
        for p in original_paragraphs:
            if not ordinary_blank(p) or p in preserve_signature_blanks:
                continue
            # A document-final paragraph immediately following a table can be
            # required by Word; leave this structural paragraph intact.
            siblings = list(body)
            index = siblings.index(p)
            if index and siblings[index - 1].tag == W + "tbl" and all(
                c.tag == W + "sectPr" for c in siblings[index + 1:]
            ):
                continue
            body.remove(p)
            removed_blanks += 1
        remaining = list(body.findall("w:p", NS))
        soft_breaks = sum(collapse_soft_breaks(p) for p in remaining)
        closing_start = find_closing(remaining)
        warnings = []
        anchor_bound = False
        closing_count = 0
        removed_closing_page_breaks = 0
        if closing_start is not None:
            first_closing = remaining[closing_start]
            # A pure page-break paragraph immediately before 此致 can itself
            # create an orphan signature page. Treat only this adjacent empty
            # spacer as part of the closing; preserve hard breaks elsewhere.
            previous = first_closing.getprevious()
            while previous is not None and previous.tag == W + "p" and not text(previous).strip():
                if any(etree.QName(n).localname in PROTECTED for n in previous.iter()):
                    break
                if any(n.get(W + "type") == "column" for n in previous.findall(".//w:br", NS)):
                    break
                page_breaks = [n for n in previous.findall(".//w:br", NS) if n.get(W + "type") == "page"]
                before = previous.find("w:pPr/w:pageBreakBefore", NS)
                before_enabled = before is not None and before.get(W + "val", "1") not in ("0", "false", "off")
                if not page_breaks and not before_enabled:
                    break
                for br in page_breaks:
                    br.getparent().remove(br)
                if before_enabled:
                    set_toggle(previous, "pageBreakBefore", False)
                removed_closing_page_breaks += len(page_breaks) + int(before_enabled)
                earlier = previous.getprevious()
                if ordinary_blank(previous):
                    body.remove(previous)
                    removed_blanks += 1
                else:
                    break
                previous = earlier
            remaining = list(body.findall("w:p", NS))
            closing = remaining[remaining.index(first_closing):]
            # Formatting across section boundaries or tables needs native layout
            # inspection; do not erase those structures just to join signatures.
            first_element = list(body).index(closing[0])
            tail_elements = list(body)[first_element:]
            section_breaks = any(p.find("w:pPr/w:sectPr", NS) is not None for p in closing)
            nonparagraph_tail = any(e.tag not in (W + "p", W + "sectPr") for e in tail_elements)
            if section_breaks or nonparagraph_tail:
                warnings.append("Closing contains a section boundary or non-paragraph block; verify grouping in Word")
            else:
                closing_count = len(closing)
                for i, p in enumerate(closing):
                    set_toggle(p, "keepNext", i < len(closing) - 1)
                    set_toggle(p, "keepLines", True)
                    set_toggle(p, "widowControl", True)
                    set_toggle(p, "pageBreakBefore", False)
                    for br in list(p.findall(".//w:br", NS)):
                        if br.get(W + "type") == "page":
                            br.getparent().remove(br)
                            removed_closing_page_breaks += 1
                # Bind the preceding body paragraph as well as the whole closing.
                # Let a long body paragraph split, retaining its last lines with
                # the signature block rather than moving a whole long paragraph.
                previous = closing[0].getprevious()
                if previous is not None and previous.tag == W + "p" and text(previous).strip():
                    if previous.find("w:pPr/w:sectPr", NS) is None:
                        if not any(etree.QName(n).localname in PROTECTED for n in previous.iter()):
                            for node in reversed(list(previous.iter())):
                                if node.tag == W + "t" and (node.text or "").strip():
                                    break
                                if node.tag == W + "br" and node.get(W + "type") == "page":
                                    node.getparent().remove(node)
                                    removed_closing_page_breaks += 1
                        set_toggle(previous, "keepNext", True)
                        set_toggle(previous, "keepLines", False)
                        set_toggle(previous, "widowControl", True)
                        anchor_bound = True
                if not anchor_bound:
                    warnings.append("No adjacent substantive body paragraph could be bound to closing; inspect final page manually")
        else:
            warnings.append("Closing was not recognized; inspect and group it using the document editor")
        if significant_text(root) != before_text:
            raise ValueError("Meaningful document text changed during layout cleanup")
        if len(root.findall(".//w:sectPr", NS)) != len(etree.fromstring(before_xml).findall(".//w:sectPr", NS)):
            raise ValueError("Section count changed")
        changes = {"word/document.xml": etree.tostring(root, xml_declaration=True, encoding="UTF-8", standalone=True)}
        # Request dynamic page-field refresh when Word opens the generated copy.
        # This is not a substitute for an actual field refresh and visual check.
        instructions = []
        for name in z.namelist():
            if name.startswith("word/") and name.endswith(".xml"):
                part_root = etree.fromstring(z.read(name))
                instructions.extend(n.text or "" for n in part_root.findall(".//w:instrText", NS))
                instructions.extend(n.get(W + "instr", "") for n in part_root.findall(".//w:fldSimple", NS))
        has_page_fields = any(re.search(r"\b(?:PAGE|NUMPAGES)\b", instruction) for instruction in instructions)
        refresh_requested = False
        if has_page_fields and "word/settings.xml" in z.namelist():
            settings = etree.fromstring(z.read("word/settings.xml"))
            update = settings.find("w:updateFields", NS)
            if update is None:
                update = etree.Element(W + "updateFields")
                later_settings = {"hdrShapeDefaults", "footnotePr", "endnotePr", "compat", "docVars", "rsids", "mathPr", "uiCompat97To2003", "attachedSchema", "themeFontLang", "clrSchemeMapping", "doNotIncludeSubdocsInStats", "doNotAutoCompressPictures", "forceUpgrade", "captions", "readModeInkLockDown", "smartTagType", "schemaLibrary", "shapeDefaults", "doNotEmbedSmartTags", "decimalSymbol", "listSeparator"}
                for i, existing in enumerate(settings):
                    if etree.QName(existing).localname in later_settings:
                        settings.insert(i, update)
                        break
                else:
                    settings.append(update)
            update.set(W + "val", "true")
            changes["word/settings.xml"] = etree.tostring(settings, xml_declaration=True, encoding="UTF-8", standalone=True)
            refresh_requested = True
        output.parent.mkdir(parents=True, exist_ok=True)
        with ZipFile(output, "w") as out:
            for info in z.infolist():
                out.writestr(info, changes.get(info.filename, z.read(info.filename)))
    with ZipFile(source) as a, ZipFile(output) as b:
        if a.namelist() != b.namelist():
            raise ValueError("Package member set changed")
        changed_parts = [n for n in a.namelist() if a.read(n) != b.read(n)]
        if any(n not in changes for n in changed_parts):
            raise ValueError("Unexpected package part changed")
        final_root = etree.fromstring(b.read("word/document.xml"))
        if significant_text(final_root) != before_text:
            raise ValueError("Final meaningful text differs")
    if hashlib.sha256(source.read_bytes()).hexdigest() != before_hash:
        raise ValueError("Input document changed")
    return {
        "input": str(source), "output": str(output), "source_unchanged": True,
        "removed_empty_body_paragraphs": removed_blanks,
        "preserved_signature_blank_paragraphs": len(preserve_signature_blanks),
        "collapsed_extra_soft_breaks": soft_breaks,
        "closing_paragraph_count": closing_count,
        "closing_bound_to_preceding_body": anchor_bound,
        "removed_page_breaks_inside_closing": removed_closing_page_breaks,
        "page_field_refresh_requested": refresh_requested,
        "meaningful_text_unchanged": True, "changed_parts": changed_parts,
        "visual_pagination_verified": False,
        "warnings": warnings,
    }


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("input")
    p.add_argument("--output", required=True)
    p.add_argument("--report")
    p.add_argument("--keep-signature-blank", type=int, choices=(0, 1), default=1)
    args = p.parse_args()
    if args.report:
        report = Path(args.report).resolve()
        if report.is_relative_to(ROOT) or report.suffix.lower() != ".json" or report in (Path(args.input).resolve(), Path(args.output).resolve()):
            raise ValueError("Use an external JSON report path distinct from the documents")
    result = format_document(args.input, args.output, args.keep_signature_blank)
    serialized = json.dumps(result, ensure_ascii=False, indent=2) + "\n"
    if args.report:
        report.parent.mkdir(parents=True, exist_ok=True)
        report.write_text(serialized, encoding="utf-8")
    else:
        print(serialized, end="")


if __name__ == "__main__":
    main()
